#!/usr/bin/env node

const restify = require('restify');
const path = require('path');
console.log('path module loaded:', path);

const server = restify.createServer();

// Add body parser to parse JSON bodies
server.use(restify.plugins.bodyParser());

server.pre(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Authorization, Content-Type");
    res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    next();
});

server.opts('*', (req, res, next) => {
    res.send(200);
    return next();
});

// Serve the default login page at the root
server.get('/', restify.plugins.serveStatic({
    directory: path.join(__dirname, '../html'),
    default: 'login.html'
}));

// Catch-all route to serve static files (including login.html)
server.get('/*', restify.plugins.serveStatic({
    directory: path.join(__dirname, '../html')
}));


const fs = require('node:fs')
const {createHmac} = require('node:crypto')

const secret = "abcdefg" //this is a secret key for hashing our passwords
const hash = (str) => createHmac("sha256", secret).update(str).digest('hex')

let users = {};
try {
  const data = fs.readFileSync('passwrd.db', 'utf8');  // read the file synchronously
  users = JSON.parse(data);
} catch (err) {
  console.log("Error reading password file: " + err);
  users["admin"] = { hash: hash("admin123"), role: "admin", comments: "Default admin" };
  fs.writeFileSync('passwrd.db', JSON.stringify(users));
}

  
const crypto = require('node:crypto');

// This is a simple example of how to hash a password using the crypto module.
// To hash a password, simply call:
const myPassword = "admin123";
const hashedPassword = hash(myPassword);

console.log(hashedPassword); // This will output the hashed password as a hex string.


	


let notes = []

const authenticate = (req) => {
	const authHeader = req.headers.authorization;
	if (!authHeader || !authHeader.startsWith("Basic ")) return false;
	
	const base64Credentials = authHeader.slice(6);
	const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
	const [username, password] = credentials.split(':');
	
	console.log("Attempting login for:", username);
	console.log("Provided password:", password);
	console.log("Hashed provided password:", hash(password));
	
	if (username in users) {
	  console.log("Stored hash:", users[username].hash);
	}
	
	if (username in users && users[username].hash === hash(password)) {
	  return { username, role: users[username].role };
	}
	return false;
  }
  
  
server.post('/api', (req, res, next) => {
	try {
		const params = JSON.parse(req.body)
		
        notes.push(params.note)
		res.send(201, params.note)
	} catch {
		res.send(400, '400: Bad Request')
	}
	return next()
})

server.get('/api', (req, res, next) => {
	//THIS NEEDS TO BE FIXED, THIS WILL BREAK WHEN WE START USING UIDS FOR NOTES
	//RIGHT NOW IT IS FINE BECAUSE WE ARENT PULLING NOTES OF A SPECIFIC ID
	//get our requested param...
	const index = req.query.index
	
	//let result hold our notes array
	let result = notes
	
	//check if we have notes... if we dont then no need to proceed
	if (!index){
		res.send(200, result)
	}
	//if our index exists, set result to that instead
	else if (index >= 0  && index < notes.length) {
		result = notes[index]
		res.send(200, result)
	}
	//else, index doesnt exist and we send 404
	else{
		res.send(404, '404: Not Found | No notes matching the search criteria')
	}

	return next()
})

server.put('/api', (req, res, next) => {
	//parse our body
	const params = JSON.parse(req.body)
	
	//get index of old note & our newnote
	const index = params.noteIndex
	const note = params.newNote

	//if we dont have a note, then something is wrong (we dont check index because thats serverside. If that isnt passed, our code sucks)
	if (!note) {
		res.send(400, '400: Bad Request | Note parameters are required')
	} 
	//else, we are successful, put change the data of note at that index, and send success
	else {
		notes[index] = note
		res.send(200, notes[index])
	}
	
	return next()
})

server.del('/api', (req, res, next) => {
	//Parse our body
	const params = JSON.parse(req.body)
	//Grab our note index
    const noteIndex = params.noteIndex
	console.log(noteIndex)

    if (noteIndex < 0 || noteIndex >= notes.length) {
            res.send(404,'404: Not Found | Note does not exist in database');
    }else {
            notes.splice(noteIndex, 1);
            res.send(200, 'Note Deleted');
    }

    return next();
})

server.post('/register', (req, res, next) => {
	// Authenticate the request using Basic Auth.
	// Only an authenticated admin is allowed.
	const adminUser = authenticate(req);
	if (!adminUser || adminUser.role !== 'admin') {
	  res.send(401, 'Unauthorized: Only admin can create new credentials');
	  return next();
	}
	
	// Extract new user details from the request body.
	const { newUsername, newPassword, role, comments } = req.body;
	
	// Validate input fields.
	if (!newUsername || !newPassword || !role) {
	  res.send(400, 'Bad Request: newUsername, newPassword, and role are required');
	  return next();
	}
	if (role !== 'admin' && role !== 'author') {
	  res.send(400, 'Bad Request: role must be either "admin" or "author"');
	  return next();
	}
	if (users[newUsername]) {
	  res.send(409, 'Conflict: User already exists');
	  return next();
	}
	
	// Create the new user. Note that we hash the password.
	users[newUsername] = {
	  hash: hash(newPassword),
	  role: role,
	  comments: comments || ''
	};
	
	// Save the updated users object back to passwrd.db.
	fs.writeFile('passwrd.db', JSON.stringify(users), (err) => {
	  if (err) {
		res.send(500, 'Internal Server Error: Could not save new user');
		return next();
	  }
	  res.send(201, `User ${newUsername} created successfully`);
	  return next();
	});
  });
	

  server.get('/login', (req, res, next) => {
	const authUser = authenticate(req);
	if (authUser) {
	  res.send(200, { username: authUser.username, role: authUser.role });
	} else {
	  res.send(401, 'Invalid credentials');
	}
	return next();
  });


  

  
/*
const handleRequest = (req, res, next) => {
  if (req.method === 'POST') {
	 
	console.log("Method = 'POST'")
    let body = ''

    req.on('data', (data) => {
      body += data
    })

    req.on('end', () => {
      const params = Object.fromEntries(body.split('&').map(
        (param) => param.split('=')
      ))

      if (!params.notePOST) {
        res.writeHead(400, { 'Content-Type': 'text/plain' })
        res.end('Bad Request: note parameters are required')
      } else {
        notes.push(params)

        res.writeHead(201, { 'Content-Type': 'application/json' })
        res.end(JSON.stringify(params))
      }
    })

  } else if (req.method === 'GET') {
	console.log("Method = 'GET'")

    const url = new URL(req.url, `http://${req.headers.host}`)
    const splitRequest = req.split(" ")
	console.log(splitRequest)
	const search = ""
	console.log("search = " + search)

    let result = notes

    if (search) {
      result = notes.filter(note => note.notePOST.includes(search))
    }

    if (result.length !== 0) {
      res.writeHead(200, { 'Content-Type': 'application/json' })
      res.end(JSON.stringify(result))
	  console.log("Found, return 200")
    } else {
      res.writeHead(404, { 'Content-Type': 'text/plain' })
      res.end('404: Not Found | No notes matching the search criteria or no notes have been entered')
	  console.log("Not Found, return 404")
    }

  } else {
    res.writeHead(405, { 'Content-Type': 'text/plain' })
    res.end('405: Method Not Allowed')
	console.log("Method not allowed, return 405")
  }
}
*/

server.listen(3000, () => {
  console.log('Server listening on port 3000')
})