document.getElementById("registerForm").addEventListener("submit", async (event) => {
  event.preventDefault();

  // Collect admin credentials for authentication
  const adminUsername = document.getElementById("adminUsername").value.trim();
  const adminPassword = document.getElementById("adminPassword").value.trim();

  // Collect new user details
  const newUsername = document.getElementById("newUsername").value.trim();
  const newPassword = document.getElementById("newPassword").value.trim();
  const role = document.getElementById("role").value;
  const comments = document.getElementById("comments").value.trim();

  // Create the Basic Auth header for admin authentication.
  const adminAuthHeader = "Basic " + btoa(adminUsername + ":" + adminPassword);

  try {
    // Send a POST request to /register with admin authentication and new user data.
    const response = await fetch("/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": adminAuthHeader
      },
      body: JSON.stringify({
        newUsername,
        newPassword,
        role,
        comments
      })
    });

    if (response.ok) {
      alert("User " + newUsername + " created successfully!");
      window.location.href = "login.html";  // Redirect back to login page.
    } else {
      const errorText = await response.text();
      alert("Registration failed: " + errorText);
    }
  } catch (error) {
    console.error("Error during registration:", error);
    alert("An error occurred during registration.");
  }
});
